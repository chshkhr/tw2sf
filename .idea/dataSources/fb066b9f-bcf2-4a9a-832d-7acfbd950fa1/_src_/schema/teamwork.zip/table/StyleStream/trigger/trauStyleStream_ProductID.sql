CREATE TRIGGER trauStyleStream_ProductID
AFTER UPDATE ON StyleStream
FOR EACH ROW
  BEGIN
  IF NEW.StyleId IS NOT NULL THEN
    INSERT INTO Styles (StyleId,ProductID) VALUES (NEW.StyleId,NEW.ProductID)
    ON DUPLICATE KEY UPDATE ProductID = NEW.ProductID;
    #UPDATE Items SET Qty = NULL WHERE StyleID = NEW.StyleId;
  END IF;
END;
